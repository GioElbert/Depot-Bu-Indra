﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Depot_bu_indra
{
    public partial class POS : Form
    {

        public static Boolean slideMenu = false;

        public POS()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LeftPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button_Strip_menu_Click(object sender, EventArgs e)
        {
            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (slideMenu)
            {
                leftPanel.Width += 25;
                panelButtonStripMenu.Width += 25;
                if (leftPanel.Width >= 150)
                {
                    timer1.Stop();
                    slideMenu = false;
                }
            }
            else
            {
                leftPanel.Width -= 25;
                panelButtonStripMenu.Width -= 25;
                if (leftPanel.Width <= 45)
                {
                    timer1.Stop();
                    slideMenu = true;
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void POSPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBoxLanding_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panelRightReport_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
