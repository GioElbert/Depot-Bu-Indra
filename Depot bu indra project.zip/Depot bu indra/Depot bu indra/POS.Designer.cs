﻿namespace Depot_bu_indra
{
    partial class POS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TopPanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelButtonStripMenu = new System.Windows.Forms.Panel();
            this.Button_Strip_menu = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelLogOut = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.leftPanel = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.POSPanel = new System.Windows.Forms.Panel();
            this.RightPanel = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelLanding = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelLanding = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelReport = new System.Windows.Forms.Panel();
            this.panelRightReport = new System.Windows.Forms.Panel();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.textBoxNetProfit = new System.Windows.Forms.TextBox();
            this.textBoxOtherCost = new System.Windows.Forms.TextBox();
            this.textBoxOpCost = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxTotalRevenue = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxTotalCost = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxCOGS = new System.Windows.Forms.TextBox();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.labelStartdate = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panelLeftReport = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label_DateChange = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.TopPanel.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelButtonStripMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.leftPanel.SuspendLayout();
            this.POSPanel.SuspendLayout();
            this.RightPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panelLanding.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelReport.SuspendLayout();
            this.panelRightReport.SuspendLayout();
            this.panelLeftReport.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // TopPanel
            // 
            this.TopPanel.Controls.Add(this.panel2);
            this.TopPanel.Controls.Add(this.panelButtonStripMenu);
            this.TopPanel.Controls.Add(this.panel1);
            this.TopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopPanel.Location = new System.Drawing.Point(0, 0);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.Size = new System.Drawing.Size(1552, 73);
            this.TopPanel.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(913, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(385, 73);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Depot_bu_indra.Properties.Resources.logo_depot_bu_indra;
            this.pictureBox3.Location = new System.Drawing.Point(20, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(60, 46);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Depot Bu Indra Surabaya";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panelButtonStripMenu
            // 
            this.panelButtonStripMenu.Controls.Add(this.Button_Strip_menu);
            this.panelButtonStripMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelButtonStripMenu.Location = new System.Drawing.Point(0, 0);
            this.panelButtonStripMenu.Name = "panelButtonStripMenu";
            this.panelButtonStripMenu.Size = new System.Drawing.Size(203, 73);
            this.panelButtonStripMenu.TabIndex = 3;
            // 
            // Button_Strip_menu
            // 
            this.Button_Strip_menu.BackgroundImage = global::Depot_bu_indra.Properties.Resources._1_removebg_preview1;
            this.Button_Strip_menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Button_Strip_menu.Dock = System.Windows.Forms.DockStyle.Right;
            this.Button_Strip_menu.FlatAppearance.BorderSize = 0;
            this.Button_Strip_menu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_Strip_menu.Location = new System.Drawing.Point(158, 0);
            this.Button_Strip_menu.Name = "Button_Strip_menu";
            this.Button_Strip_menu.Size = new System.Drawing.Size(45, 73);
            this.Button_Strip_menu.TabIndex = 0;
            this.Button_Strip_menu.UseVisualStyleBackColor = true;
            this.Button_Strip_menu.Click += new System.EventHandler(this.Button_Strip_menu_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelLogOut);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1298, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(254, 73);
            this.panel1.TabIndex = 4;
            // 
            // labelLogOut
            // 
            this.labelLogOut.AutoSize = true;
            this.labelLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogOut.Location = new System.Drawing.Point(182, 43);
            this.labelLogOut.Name = "labelLogOut";
            this.labelLogOut.Size = new System.Drawing.Size(60, 16);
            this.labelLogOut.TabIndex = 3;
            this.labelLogOut.Text = "Log Out";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Depot_bu_indra.Properties.Resources._7_removebg_preview__1_;
            this.pictureBox2.Location = new System.Drawing.Point(13, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(56, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nathan Gunawan";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label3.Location = new System.Drawing.Point(75, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Manager";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // leftPanel
            // 
            this.leftPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.leftPanel.Controls.Add(this.button11);
            this.leftPanel.Controls.Add(this.button10);
            this.leftPanel.Controls.Add(this.button9);
            this.leftPanel.Controls.Add(this.button8);
            this.leftPanel.Controls.Add(this.button12);
            this.leftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftPanel.Location = new System.Drawing.Point(0, 73);
            this.leftPanel.Name = "leftPanel";
            this.leftPanel.Size = new System.Drawing.Size(200, 580);
            this.leftPanel.TabIndex = 0;
            this.leftPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.LeftPanel_Paint);
            // 
            // button11
            // 
            this.button11.BackgroundImage = global::Depot_bu_indra.Properties.Resources._6_removebg_Expense;
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(6, 167);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(188, 50);
            this.button11.TabIndex = 25;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.BackgroundImage = global::Depot_bu_indra.Properties.Resources._3_removebg_SOP;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(9, 223);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(194, 50);
            this.button10.TabIndex = 24;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::Depot_bu_indra.Properties.Resources._5_removebg_Report_and_History;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(3, 111);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(181, 50);
            this.button9.TabIndex = 23;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::Depot_bu_indra.Properties.Resources._4_removebg_Maintance_Item_Master1;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(0, 57);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(181, 50);
            this.button8.TabIndex = 22;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.BackgroundImage = global::Depot_bu_indra.Properties.Resources._2_removebg_POS2;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(0, 4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(197, 50);
            this.button12.TabIndex = 21;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 57);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "Foods";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // POSPanel
            // 
            this.POSPanel.Controls.Add(this.button1);
            this.POSPanel.Controls.Add(this.RightPanel);
            this.POSPanel.Controls.Add(this.button3);
            this.POSPanel.Controls.Add(this.flowLayoutPanel1);
            this.POSPanel.Controls.Add(this.button2);
            this.POSPanel.Location = new System.Drawing.Point(1452, 130);
            this.POSPanel.Name = "POSPanel";
            this.POSPanel.Size = new System.Drawing.Size(640, 360);
            this.POSPanel.TabIndex = 2;
            this.POSPanel.Visible = false;
            this.POSPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.POSPanel_Paint);
            // 
            // RightPanel
            // 
            this.RightPanel.Controls.Add(this.button13);
            this.RightPanel.Controls.Add(this.label10);
            this.RightPanel.Controls.Add(this.pictureBox6);
            this.RightPanel.Controls.Add(this.pictureBox5);
            this.RightPanel.Controls.Add(this.label8);
            this.RightPanel.Controls.Add(this.button6);
            this.RightPanel.Controls.Add(this.button7);
            this.RightPanel.Controls.Add(this.button4);
            this.RightPanel.Controls.Add(this.label9);
            this.RightPanel.Controls.Add(this.button5);
            this.RightPanel.Controls.Add(this.label7);
            this.RightPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.RightPanel.Location = new System.Drawing.Point(454, 0);
            this.RightPanel.Name = "RightPanel";
            this.RightPanel.Size = new System.Drawing.Size(186, 360);
            this.RightPanel.TabIndex = 3;
            // 
            // button13
            // 
            this.button13.BackgroundImage = global::Depot_bu_indra.Properties.Resources._13_removebg_preview;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(138, 4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(45, 50);
            this.button13.TabIndex = 8;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(92, 215);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 16);
            this.label10.TabIndex = 6;
            this.label10.Text = "Emp:";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Depot_bu_indra.Properties.Resources.download;
            this.pictureBox6.Location = new System.Drawing.Point(-3, 94);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(186, 36);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Depot_bu_indra.Properties.Resources.download;
            this.pictureBox5.Location = new System.Drawing.Point(3, 173);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(180, 36);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Total ";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(3, 258);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 49);
            this.button6.TabIndex = 6;
            this.button6.Text = "Create Bill";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(95, 324);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 49);
            this.button7.TabIndex = 7;
            this.button7.Text = "Print Receipt";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(3, 324);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 49);
            this.button4.TabIndex = 4;
            this.button4.Text = "Open Bill";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 215);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "Cust:";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(95, 258);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 49);
            this.button5.TabIndex = 5;
            this.button5.Text = "Save Bill";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Table ";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(131, 57);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 42);
            this.button3.TabIndex = 6;
            this.button3.Text = "Drinks";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.checkedListBox1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 105);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(447, 333);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.numericUpDown1);
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(135, 136);
            this.panel6.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "35.000";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(92, 103);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(37, 22);
            this.numericUpDown1.TabIndex = 2;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Depot_bu_indra.Properties.Resources.nasi_campur;
            this.pictureBox4.Location = new System.Drawing.Point(3, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(120, 87);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Nasi campur";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(144, 3);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(8, 4);
            this.checkedListBox1.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(252, 57);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 42);
            this.button2.TabIndex = 5;
            this.button2.Text = "Snacks";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panelLanding
            // 
            this.panelLanding.Controls.Add(this.label12);
            this.panelLanding.Controls.Add(this.label11);
            this.panelLanding.Controls.Add(this.label4);
            this.panelLanding.Controls.Add(this.labelLanding);
            this.panelLanding.Controls.Add(this.pictureBox1);
            this.panelLanding.Location = new System.Drawing.Point(1256, 386);
            this.panelLanding.Name = "panelLanding";
            this.panelLanding.Size = new System.Drawing.Size(640, 360);
            this.panelLanding.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(314, 197);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 42);
            this.label12.TabIndex = 5;
            this.label12.Text = "INDRA";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(314, 155);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(211, 42);
            this.label11.TabIndex = 4;
            this.label11.Text = "DEPOT BU";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(314, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(273, 42);
            this.label4.TabIndex = 3;
            this.label4.Text = "WELCOME TO";
            // 
            // labelLanding
            // 
            this.labelLanding.AutoSize = true;
            this.labelLanding.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLanding.Location = new System.Drawing.Point(-147, 140);
            this.labelLanding.Name = "labelLanding";
            this.labelLanding.Size = new System.Drawing.Size(0, 69);
            this.labelLanding.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Depot_bu_indra.Properties.Resources.logo_depot_bu_indra;
            this.pictureBox1.Location = new System.Drawing.Point(17, 66);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 215);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panelReport
            // 
            this.panelReport.Controls.Add(this.panelRightReport);
            this.panelReport.Controls.Add(this.panelLeftReport);
            this.panelReport.Controls.Add(this.label16);
            this.panelReport.Location = new System.Drawing.Point(251, 100);
            this.panelReport.Name = "panelReport";
            this.panelReport.Size = new System.Drawing.Size(840, 460);
            this.panelReport.TabIndex = 4;
            // 
            // panelRightReport
            // 
            this.panelRightReport.Controls.Add(this.button18);
            this.panelRightReport.Controls.Add(this.button17);
            this.panelRightReport.Controls.Add(this.button14);
            this.panelRightReport.Controls.Add(this.textBoxNetProfit);
            this.panelRightReport.Controls.Add(this.textBoxOtherCost);
            this.panelRightReport.Controls.Add(this.textBoxOpCost);
            this.panelRightReport.Controls.Add(this.label23);
            this.panelRightReport.Controls.Add(this.textBoxTotalRevenue);
            this.panelRightReport.Controls.Add(this.label24);
            this.panelRightReport.Controls.Add(this.label22);
            this.panelRightReport.Controls.Add(this.textBoxTotalCost);
            this.panelRightReport.Controls.Add(this.label21);
            this.panelRightReport.Controls.Add(this.label20);
            this.panelRightReport.Controls.Add(this.label19);
            this.panelRightReport.Controls.Add(this.textBoxCOGS);
            this.panelRightReport.Controls.Add(this.monthCalendar2);
            this.panelRightReport.Controls.Add(this.monthCalendar1);
            this.panelRightReport.Controls.Add(this.comboBox3);
            this.panelRightReport.Controls.Add(this.comboBox2);
            this.panelRightReport.Controls.Add(this.label14);
            this.panelRightReport.Controls.Add(this.labelStartdate);
            this.panelRightReport.Controls.Add(this.label13);
            this.panelRightReport.Location = new System.Drawing.Point(215, 3);
            this.panelRightReport.Name = "panelRightReport";
            this.panelRightReport.Size = new System.Drawing.Size(622, 454);
            this.panelRightReport.TabIndex = 4;
            this.panelRightReport.Paint += new System.Windows.Forms.PaintEventHandler(this.panelRightReport_Paint);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(509, 405);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(90, 42);
            this.button18.TabIndex = 36;
            this.button18.Text = "Statistic Report";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(413, 405);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(90, 42);
            this.button17.TabIndex = 35;
            this.button17.Text = "Yearly Graphic";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(317, 406);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(90, 42);
            this.button14.TabIndex = 34;
            this.button14.Text = "Enter";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // textBoxNetProfit
            // 
            this.textBoxNetProfit.Location = new System.Drawing.Point(350, 374);
            this.textBoxNetProfit.Name = "textBoxNetProfit";
            this.textBoxNetProfit.Size = new System.Drawing.Size(252, 22);
            this.textBoxNetProfit.TabIndex = 33;
            // 
            // textBoxOtherCost
            // 
            this.textBoxOtherCost.Location = new System.Drawing.Point(433, 322);
            this.textBoxOtherCost.Name = "textBoxOtherCost";
            this.textBoxOtherCost.Size = new System.Drawing.Size(151, 22);
            this.textBoxOtherCost.TabIndex = 32;
            // 
            // textBoxOpCost
            // 
            this.textBoxOpCost.Location = new System.Drawing.Point(240, 322);
            this.textBoxOpCost.Name = "textBoxOpCost";
            this.textBoxOpCost.Size = new System.Drawing.Size(151, 22);
            this.textBoxOpCost.TabIndex = 31;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(32, 406);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 20);
            this.label23.TabIndex = 30;
            this.label23.Text = "Total Revenue";
            // 
            // textBoxTotalRevenue
            // 
            this.textBoxTotalRevenue.Location = new System.Drawing.Point(36, 429);
            this.textBoxTotalRevenue.Name = "textBoxTotalRevenue";
            this.textBoxTotalRevenue.Size = new System.Drawing.Size(224, 22);
            this.textBoxTotalRevenue.TabIndex = 29;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(346, 351);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 20);
            this.label24.TabIndex = 28;
            this.label24.Text = "Net Profit";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(32, 351);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 20);
            this.label22.TabIndex = 24;
            this.label22.Text = "Total Cost";
            // 
            // textBoxTotalCost
            // 
            this.textBoxTotalCost.Location = new System.Drawing.Point(36, 374);
            this.textBoxTotalCost.Name = "textBoxTotalCost";
            this.textBoxTotalCost.Size = new System.Drawing.Size(252, 22);
            this.textBoxTotalCost.TabIndex = 23;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(429, 298);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(74, 20);
            this.label21.TabIndex = 22;
            this.label21.Text = "Other Cost";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(236, 299);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(112, 20);
            this.label20.TabIndex = 21;
            this.label20.Text = "Operational Cost";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(32, 299);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 20);
            this.label19.TabIndex = 18;
            this.label19.Text = "COGS";
            // 
            // textBoxCOGS
            // 
            this.textBoxCOGS.Location = new System.Drawing.Point(36, 322);
            this.textBoxCOGS.Name = "textBoxCOGS";
            this.textBoxCOGS.Size = new System.Drawing.Size(151, 22);
            this.textBoxCOGS.TabIndex = 17;
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.Location = new System.Drawing.Point(306, 83);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 16;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(26, 83);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 15;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(306, 46);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(85, 24);
            this.comboBox3.TabIndex = 14;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(26, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(85, 24);
            this.comboBox2.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(302, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 19);
            this.label14.TabIndex = 13;
            this.label14.Text = "End Date";
            // 
            // labelStartdate
            // 
            this.labelStartdate.AutoSize = true;
            this.labelStartdate.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStartdate.Location = new System.Drawing.Point(22, 24);
            this.labelStartdate.Name = "labelStartdate";
            this.labelStartdate.Size = new System.Drawing.Size(89, 19);
            this.labelStartdate.TabIndex = 12;
            this.labelStartdate.Text = "Start Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 34);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 16);
            this.label13.TabIndex = 10;
            // 
            // panelLeftReport
            // 
            this.panelLeftReport.Controls.Add(this.panel4);
            this.panelLeftReport.Controls.Add(this.label_DateChange);
            this.panelLeftReport.Controls.Add(this.comboBox1);
            this.panelLeftReport.Location = new System.Drawing.Point(4, 1);
            this.panelLeftReport.Name = "panelLeftReport";
            this.panelLeftReport.Size = new System.Drawing.Size(205, 457);
            this.panelLeftReport.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.pictureBox7);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 43);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(205, 85);
            this.panel4.TabIndex = 12;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(164, 8);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(38, 16);
            this.label28.TabIndex = 3;
            this.label28.Text = "10:02";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(64, 24);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(529, 16);
            this.label27.TabIndex = 2;
            this.label27.Text = "1x Nasi Campur, 2x Nasi Bakmoi, 1x Es Teh Tawar, 2x Es Teh manis, 5x Nasi Kare Ay" +
    "am";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(64, 3);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(74, 16);
            this.label26.TabIndex = 1;
            this.label26.Text = "RP 250.000";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(4, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(54, 56);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // label_DateChange
            // 
            this.label_DateChange.AutoSize = true;
            this.label_DateChange.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_DateChange.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DateChange.Location = new System.Drawing.Point(0, 24);
            this.label_DateChange.Name = "label_DateChange";
            this.label_DateChange.Size = new System.Drawing.Size(108, 19);
            this.label_DateChange.TabIndex = 11;
            this.label_DateChange.Text = "2 Maret 2023";
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(205, 24);
            this.comboBox1.TabIndex = 10;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(-147, 140);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 69);
            this.label16.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.button15);
            this.panel3.Controls.Add(this.button16);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Location = new System.Drawing.Point(1358, 248);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(640, 360);
            this.panel3.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(415, 270);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 24);
            this.label15.TabIndex = 8;
            this.label15.Text = "Catalog";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(129, 273);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 24);
            this.label17.TabIndex = 5;
            this.label17.Text = "Employee";
            // 
            // button15
            // 
            this.button15.BackgroundImage = global::Depot_bu_indra.Properties.Resources.Employee_crop;
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button15.Location = new System.Drawing.Point(53, 61);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(246, 205);
            this.button15.TabIndex = 7;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.BackgroundImage = global::Depot_bu_indra.Properties.Resources.Catalog_crop;
            this.button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button16.Location = new System.Drawing.Point(338, 59);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(246, 205);
            this.button16.TabIndex = 6;
            this.button16.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(-147, 140);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 69);
            this.label18.TabIndex = 2;
            // 
            // POS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1552, 653);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelReport);
            this.Controls.Add(this.panelLanding);
            this.Controls.Add(this.POSPanel);
            this.Controls.Add(this.leftPanel);
            this.Controls.Add(this.TopPanel);
            this.Name = "POS";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TopPanel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelButtonStripMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.leftPanel.ResumeLayout(false);
            this.POSPanel.ResumeLayout(false);
            this.RightPanel.ResumeLayout(false);
            this.RightPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panelLanding.ResumeLayout(false);
            this.panelLanding.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelReport.ResumeLayout(false);
            this.panelReport.PerformLayout();
            this.panelRightReport.ResumeLayout(false);
            this.panelRightReport.PerformLayout();
            this.panelLeftReport.ResumeLayout(false);
            this.panelLeftReport.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel TopPanel;
        private System.Windows.Forms.Panel leftPanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel POSPanel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel RightPanel;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Button_Strip_menu;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelLogOut;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelButtonStripMenu;
        private System.Windows.Forms.Panel panelLanding;
        private System.Windows.Forms.Label labelLanding;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelReport;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panelRightReport;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelStartdate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panelLeftReport;
        private System.Windows.Forms.Label label_DateChange;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxTotalRevenue;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxTotalCost;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxCOGS;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBoxNetProfit;
        private System.Windows.Forms.TextBox textBoxOtherCost;
        private System.Windows.Forms.TextBox textBoxOpCost;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}

