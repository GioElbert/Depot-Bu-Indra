﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Depot_bu_indra
{
    public partial class Login_Page : Form
    {
        public Login_Page()
        {
            InitializeComponent();
        }

        private void labelSignUp_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_Regis.Visible = true;
        }

        private void labelLogin_Click(object sender, EventArgs e)
        {
            panel_login.Visible = true;
            panel_Regis.Visible = false;
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (textBoxUserLogin.Text == "Gio" && textBoxPassLogin.Text == "1234")
            {
                Form formPost = new POS();
                formPost.ShowDialog();
                Form Login_Page = new Login_Page();
                Login_Page.Close();
                this.Close();
            }
        }

        private void textBoxUserLogin_Enter(object sender, EventArgs e)
        {
            if (textBoxUserLogin.Text == "Input user name...")
            {
                textBoxUserLogin.Text = "";
            }

        }

        private void textBoxUserLogin_Leave(object sender, EventArgs e)
        {
            if (textBoxUserLogin.Text == "")
            {
                textBoxUserLogin.Text = "Input user name...";
                {
                }

            }
        }

        private void textBoxPassLogin_Enter(object sender, EventArgs e)
        {
            if (textBoxPassLogin.Text == "Input Password...")
            {
                textBoxPassLogin.Text = "";
            }
        }

        private void textBoxPassLogin_Leave(object sender, EventArgs e)
        {
            if (textBoxPassLogin.Text == "")
            {
                textBoxPassLogin.Text = "Input Password...";
            }
        }

        private void textBoxUserRegis_Enter(object sender, EventArgs e)
        {
            if (textBoxUserRegis.Text == "Input user name...")
            {
                textBoxUserRegis.Text = "";
                {
                }

            }
        }

        private void textBoxUserRegis_Leave(object sender, EventArgs e)
        {
            if (textBoxUserRegis.Text == "")
            {
                textBoxUserRegis.Text = "Input user name...";
                {
                }

            }
        }

        private void textBoxPassRegis_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxPassRegis_Enter(object sender, EventArgs e)
        {
            if (textBoxPassRegis.Text == "Input Password...")
            {
                textBoxPassRegis.Text = "";
                {
                }

            }
        }

        private void textBoxPassRegis_Leave(object sender, EventArgs e)
        {
            if (textBoxPassRegis.Text == "")
            {
                textBoxPassRegis.Text = "Input Password...";
                {
                }

            }
        }

        private void textBoxRoleRegis_Enter(object sender, EventArgs e)
        {
            if (textBoxRoleRegis.Text == "Manager/Employee/Owner")
            {
                textBoxRoleRegis.Text = "";
                {
                }

            }
        }

        private void textBoxRoleRegis_Leave(object sender, EventArgs e)
        {
            if (textBoxRoleRegis.Text == "")
            {
                textBoxRoleRegis.Text = "Manager/Employee/Owner";
                {
                }

            }
        }
    }
}
